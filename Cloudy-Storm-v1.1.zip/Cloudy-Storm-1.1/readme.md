# A LinkStack Theme
Find more themes: https://linkstack.org/themes
                                                                                                                                                                         
*	Theme Name: Cloudy Storm
*	Theme Version: 1.1
*	Theme Date: 2022-05-22
*	Theme Author: JulianPrieber
*	Theme Author URI: https://github.com/JulianPrieber
*	Theme License: MIT
*	Source code: https://github.com/LinkStackOrg/Cloudy-Storm

### Used assets:
* Built using:
* https://github.com/dhg/Skeleton
* License: MIT

* Built using:
* https://codepen.io/ArvidW/pen/poKMrBR
* License: MIT
